var port = 9001;
var io = require('socket.io').listen(port);
console.log((new Date()) + " Server is listening on port " + port);

var roomnames = {};
var navi = {};
var offerFilter = {};

io.sockets.on('connection', function(socket) {
  console.log("connection start with " + socket.id);
  // 入室
  socket.on('enter', function(roomname) {
    console.log(""+socket.id+":enter to "+roomname);
    roomnames[socket.id] = roomname;
    var message = {"type": "enter_room", "from": socket.id };
    emitMessage('message',message);

    socket.join(roomname);
  });

  //メッセージ
  socket.on('message', function(message) {
    message.from = socket.id;
    var target = message.sendto;
    if (target) {
      socket.to(target).emit('message', message);
      return;
    }
    emitMessage('message', message);
  });

  //ナビゲータになる
  socket.on('be_navi', function(team) {
    if(!navi[roomnames[socket.id]]){
      navi[roomnames[socket.id]] = {};
    }
    if(!navi[roomnames[socket.id]][team]){
      navi[roomnames[socket.id]][team] = socket.id;
      socket.emit('message',{"type":"navigator","team":team,"isme":true});
      emitMessage('message',{"type":"navigator","team":team,"from":socket.id});
    }
  });

  //sendOfferフィルタ
  socket.on('send_offer', function(str) {
    var data = JSON.parse(str);
    var roomname = roomnames[socket.id];
    if(!offerFilter[roomname]){
      offerFilter[roomname] = {};
    }

    var canSend = true;
    var table = offerFilter[roomname];
    //今送ろうとしている相手(to)はofferを送った事があるか
    if(table[data.sendto]){
      //あるなら自分(socket.id)に送っているか
      if(table[data.sendto][socket.id]){
        //その場合は送らない
        canSend = false;
      }
    }
    if(canSend){
      console.log("offer send from "+socket.id+" to "+data.sendto);
      data.from = socket.id;
      socket.to(data.sendto).emit('message', data);
      if(!table[socket.id]){
        table[socket.id]={};
      }
      table[socket.id][data.sendto] = true;
    }
  });

  //切断
  socket.on('disconnect', function(team) {
    if(navi[roomnames[socket.id]]){navi[roomnames[socket.id]]=null;}
    console.log(""+socket.id+":disconnect");
    var message = {"type": "disconnect", "from": socket.id };
    emitMessage('message',message);
  });

  // 会議室名が指定されていたら、室内だけに通知
  function emitMessage(type, message) {
    var roomname;
    if(roomnames[socket.id]!=undefined) roomname = roomnames[socket.id];
    if (roomname){socket.broadcast.to(roomname).emit(type, message);}
    else {socket.broadcast.emit(type, message);}
  }
});