var port = 8124;
var io = require('socket.io').listen(port);
console.log((new Date()) + " Server is listening on port " + port);

io.on('connection', function(socket) {
  console.log("connection start for " + socket.id);

  socket.on("enter", function(roomname){
    socket.set('roomname', roomname);
    socket.join(roomname);
    var message = {type: "enter_room", from: socket.id };
    emitMessage('message',message);
  });

  socket.on('message', function(message) {
    message.from = socket.id;
    var target = message.sendto;
    if(target){
      io.sockets.socket(target).emit('message', message);
      return;
    }
    emitMessage('message', message);
  });


  socket.on('disconnect', function() {
    socket.broadcast.emit('user disconnected');
  });

  function emitMessage(type, message) {
    var roomname;
    //socketに紐付いているroomnameをget
    socket.get('roomname', function(err, _room) {  roomname = _room;  });

    if (roomname) {  socket.broadcast.to(roomname).emit(type, message);   }
    else {   socket.broadcast.emit(type, message);   }
  }
});

